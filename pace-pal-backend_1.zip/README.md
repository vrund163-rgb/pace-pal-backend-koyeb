# Pace Pal API

The backend for Pace Pal. Runs real video analysis:

- **Video metadata** (fps, resolution, duration) -- read directly from the file with OpenCV.
- **Video quality heuristics** (brightness, sharpness/blur, camera-stability) -- computed from sampled real frames.
- **Ball detection & tracking** -- real trained YOLOv8 object detection (COCO-pretrained, "sports ball"
  class), adapted from the approach in https://github.com/kushagra3204/Cricket-Ball-Trajectory-Prediction.
  Runs via **ONNX Runtime** rather than the full torch/ultralytics stack -- same model weights, same
  detection quality, but ~160MB peak memory instead of ~870MB, which is what makes this fit a genuinely
  free, no-credit-card host. The model was exported once (offline, not part of this app) from
  `yolov8n.pt` to `app/models/yolov8n.onnx` via `model.export(format='onnx')`; the deployed app never
  imports torch or ultralytics.

**Not implemented yet:** camera calibration (so no real-world pace/line/length -- only pixel-space
tracking), splitting a session into distinct deliveries, swing/spin analysis. See `app/main.py`'s
`process_session()` for exactly what each pipeline stage does or doesn't do. Every result is honest
about this: fields that aren't measured come back empty/null, not invented.

## Memory footprint

Measured peak RSS ~160MB for the full pipeline including ONNX inference. Comfortably fits Render's
free tier (512MB) with plenty of headroom.

## Local development

```bash
python3 -m venv venv
./venv/bin/pip install -r requirements.txt
./venv/bin/uvicorn app.main:app --reload --port 8000
```

Test it:
```bash
curl http://localhost:8000/health
curl -X POST http://localhost:8000/api/sessions/upload -F "file=@/path/to/video.mp4"
curl http://localhost:8000/api/sessions/{sessionId}
```

## Deploy to Render (free tier)

1. Push this project to its own GitHub repo (separate from the frontend repo).
2. On render.com: New -> Web Service -> connect the repo.
3. Render should read `render.yaml` automatically. If asked manually:
   - Build command: `pip install -r requirements.txt`
   - Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
4. Free tier (512MB) works fine -- no card required.
5. Once deployed you'll get a URL like `https://pace-pal-api.onrender.com`.

Note: Render's free tier spins the service down after inactivity, so the first request after a while
will be slow (cold start) -- normal, not a bug.

**Important:** make sure `app/models/yolov8n.onnx` (the ~12MB model file) is actually included when you
upload to GitHub -- it's a binary file, so double check it made it into the repo the same way you'd
check any other file.

## Connecting the frontend

In the frontend project, set the environment variable `VITE_API_BASE_URL` to your deployed backend URL
(see `.env.example` there). The frontend's "Analyze real video" page
(`src/pages/UploadReal.tsx`) calls `POST {VITE_API_BASE_URL}/api/sessions/upload` and polls
`GET {VITE_API_BASE_URL}/api/sessions/{id}` until processing completes.

CORS is currently wide open (`allow_origins=["*"]`) in `app/main.py` to make initial testing easy.
Once your Netlify URL is stable, tighten this to that exact origin.

## API contract

`app/models.py` mirrors the frontend's `src/types/index.ts`. If you add a field on one side, add it on
the other -- that's what keeps "swap sample data for a real API call" actually true.
